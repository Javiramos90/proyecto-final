document.getElementById('galicia').addEventListener('click', e => {
    alert("Soy Galicia");
})